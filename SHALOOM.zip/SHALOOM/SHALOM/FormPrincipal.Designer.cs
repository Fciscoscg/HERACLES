﻿namespace SHALOM
{
    partial class FormPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            Menu = new Panel();
            Reportes = new FontAwesome.Sharp.IconButton();
            Pagos = new FontAwesome.Sharp.IconButton();
            Pedidos = new FontAwesome.Sharp.IconButton();
            Clientes = new FontAwesome.Sharp.IconButton();
            Dashboard = new FontAwesome.Sharp.IconButton();
            Logo = new Panel();
            Inicio = new PictureBox();
            Titulobarra = new Panel();
            Tiempo = new Label();
            pictureBox1 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            Menu.SuspendLayout();
            Logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Inicio).BeginInit();
            Titulobarra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Menu
            // 
            Menu.BackColor = Color.WhiteSmoke;
            Menu.Controls.Add(Reportes);
            Menu.Controls.Add(Pagos);
            Menu.Controls.Add(Pedidos);
            Menu.Controls.Add(Clientes);
            Menu.Controls.Add(Dashboard);
            Menu.Controls.Add(Logo);
            Menu.Dock = DockStyle.Left;
            Menu.Location = new Point(0, 0);
            Menu.Margin = new Padding(3, 4, 3, 4);
            Menu.Name = "Menu";
            Menu.Size = new Size(200, 672);
            Menu.TabIndex = 0;
            // 
            // Reportes
            // 
            Reportes.Anchor = AnchorStyles.None;
            Reportes.FlatAppearance.BorderSize = 0;
            Reportes.FlatStyle = FlatStyle.Flat;
            Reportes.Font = new Font("Century Gothic", 9.75F);
            Reportes.ForeColor = Color.Black;
            Reportes.IconChar = FontAwesome.Sharp.IconChar.ClipboardCheck;
            Reportes.IconColor = Color.Black;
            Reportes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Reportes.IconSize = 35;
            Reportes.ImageAlign = ContentAlignment.MiddleLeft;
            Reportes.Location = new Point(5, 499);
            Reportes.Margin = new Padding(3, 4, 3, 4);
            Reportes.Name = "Reportes";
            Reportes.Padding = new Padding(11, 0, 23, 0);
            Reportes.Size = new Size(190, 76);
            Reportes.TabIndex = 7;
            Reportes.Text = "Reportes";
            Reportes.TextAlign = ContentAlignment.MiddleLeft;
            Reportes.TextImageRelation = TextImageRelation.ImageBeforeText;
            Reportes.UseVisualStyleBackColor = true;
            Reportes.Click += Reportes_Click;
            // 
            // Pagos
            // 
            Pagos.Anchor = AnchorStyles.None;
            Pagos.FlatAppearance.BorderSize = 0;
            Pagos.FlatStyle = FlatStyle.Flat;
            Pagos.Font = new Font("Century Gothic", 9.75F);
            Pagos.ForeColor = Color.Black;
            Pagos.IconChar = FontAwesome.Sharp.IconChar.FileInvoiceDollar;
            Pagos.IconColor = Color.Black;
            Pagos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Pagos.IconSize = 35;
            Pagos.ImageAlign = ContentAlignment.MiddleLeft;
            Pagos.Location = new Point(5, 415);
            Pagos.Margin = new Padding(3, 4, 3, 4);
            Pagos.Name = "Pagos";
            Pagos.Padding = new Padding(11, 0, 23, 0);
            Pagos.Size = new Size(190, 76);
            Pagos.TabIndex = 6;
            Pagos.Text = "Pagos";
            Pagos.TextAlign = ContentAlignment.MiddleLeft;
            Pagos.TextImageRelation = TextImageRelation.ImageBeforeText;
            Pagos.UseVisualStyleBackColor = true;
            Pagos.Click += Pagos_Click;
            // 
            // Pedidos
            // 
            Pedidos.Anchor = AnchorStyles.None;
            Pedidos.FlatAppearance.BorderSize = 0;
            Pedidos.FlatStyle = FlatStyle.Flat;
            Pedidos.Font = new Font("Century Gothic", 9.75F);
            Pedidos.ForeColor = Color.Black;
            Pedidos.IconChar = FontAwesome.Sharp.IconChar.Truck;
            Pedidos.IconColor = Color.Black;
            Pedidos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Pedidos.IconSize = 35;
            Pedidos.ImageAlign = ContentAlignment.MiddleLeft;
            Pedidos.Location = new Point(5, 331);
            Pedidos.Margin = new Padding(3, 4, 3, 4);
            Pedidos.Name = "Pedidos";
            Pedidos.Padding = new Padding(11, 0, 23, 0);
            Pedidos.Size = new Size(190, 76);
            Pedidos.TabIndex = 5;
            Pedidos.Text = "Pedidos";
            Pedidos.TextAlign = ContentAlignment.MiddleLeft;
            Pedidos.TextImageRelation = TextImageRelation.ImageBeforeText;
            Pedidos.UseVisualStyleBackColor = true;
            Pedidos.Click += Pedidos_Click;
            // 
            // Clientes
            // 
            Clientes.Anchor = AnchorStyles.None;
            Clientes.FlatAppearance.BorderSize = 0;
            Clientes.FlatStyle = FlatStyle.Flat;
            Clientes.Font = new Font("Century Gothic", 9.75F);
            Clientes.ForeColor = Color.Black;
            Clientes.IconChar = FontAwesome.Sharp.IconChar.UserLarge;
            Clientes.IconColor = Color.Black;
            Clientes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Clientes.IconSize = 35;
            Clientes.ImageAlign = ContentAlignment.MiddleLeft;
            Clientes.Location = new Point(5, 247);
            Clientes.Margin = new Padding(3, 4, 3, 4);
            Clientes.Name = "Clientes";
            Clientes.Padding = new Padding(11, 0, 23, 0);
            Clientes.Size = new Size(190, 76);
            Clientes.TabIndex = 4;
            Clientes.Text = "Clientes";
            Clientes.TextAlign = ContentAlignment.MiddleLeft;
            Clientes.TextImageRelation = TextImageRelation.ImageBeforeText;
            Clientes.UseVisualStyleBackColor = true;
            Clientes.Click += Clientes_Click;
            // 
            // Dashboard
            // 
            Dashboard.Anchor = AnchorStyles.None;
            Dashboard.FlatAppearance.BorderSize = 0;
            Dashboard.FlatStyle = FlatStyle.Flat;
            Dashboard.Font = new Font("Century Gothic", 9.75F);
            Dashboard.ForeColor = Color.Black;
            Dashboard.IconChar = FontAwesome.Sharp.IconChar.Poll;
            Dashboard.IconColor = Color.Black;
            Dashboard.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Dashboard.IconSize = 35;
            Dashboard.ImageAlign = ContentAlignment.MiddleLeft;
            Dashboard.Location = new Point(5, 163);
            Dashboard.Margin = new Padding(3, 4, 3, 4);
            Dashboard.Name = "Dashboard";
            Dashboard.Padding = new Padding(11, 0, 23, 0);
            Dashboard.Size = new Size(190, 76);
            Dashboard.TabIndex = 3;
            Dashboard.Text = "Dashboard";
            Dashboard.TextAlign = ContentAlignment.MiddleLeft;
            Dashboard.TextImageRelation = TextImageRelation.ImageBeforeText;
            Dashboard.UseVisualStyleBackColor = true;
            Dashboard.Click += Dashboard_Click;
            // 
            // Logo
            // 
            Logo.Controls.Add(Inicio);
            Logo.Dock = DockStyle.Top;
            Logo.Location = new Point(0, 0);
            Logo.Margin = new Padding(3, 4, 3, 4);
            Logo.Name = "Logo";
            Logo.Size = new Size(200, 93);
            Logo.TabIndex = 1;
            // 
            // Inicio
            // 
            Inicio.Image = (Image)resources.GetObject("Inicio.Image");
            Inicio.Location = new Point(3, 4);
            Inicio.Margin = new Padding(3, 4, 3, 4);
            Inicio.Name = "Inicio";
            Inicio.Size = new Size(197, 105);
            Inicio.SizeMode = PictureBoxSizeMode.Zoom;
            Inicio.TabIndex = 0;
            Inicio.TabStop = false;
            Inicio.Click += Inicio_Click;
            // 
            // Titulobarra
            // 
            Titulobarra.BackColor = Color.WhiteSmoke;
            Titulobarra.Controls.Add(Tiempo);
            Titulobarra.Dock = DockStyle.Top;
            Titulobarra.Location = new Point(200, 0);
            Titulobarra.Margin = new Padding(3, 4, 3, 4);
            Titulobarra.Name = "Titulobarra";
            Titulobarra.Size = new Size(894, 93);
            Titulobarra.TabIndex = 1;
            // 
            // Tiempo
            // 
            Tiempo.Anchor = AnchorStyles.None;
            Tiempo.AutoSize = true;
            Tiempo.Font = new Font("Century Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Tiempo.Location = new Point(286, 25);
            Tiempo.Name = "Tiempo";
            Tiempo.Size = new Size(134, 40);
            Tiempo.TabIndex = 0;
            Tiempo.Text = "Tiempo";
            Tiempo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(480, 183);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(344, 392);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // FormPrincipal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1094, 672);
            Controls.Add(pictureBox1);
            Controls.Add(Titulobarra);
            Controls.Add(Menu);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Menu.ResumeLayout(false);
            Logo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Inicio).EndInit();
            Titulobarra.ResumeLayout(false);
            Titulobarra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel Menu;
        private Panel Logo;
        private FontAwesome.Sharp.IconButton Pagos;
        private FontAwesome.Sharp.IconButton Pedidos;
        private FontAwesome.Sharp.IconButton Clientes;
        private FontAwesome.Sharp.IconButton Dashboard;
        private FontAwesome.Sharp.IconButton Reportes;
        private PictureBox Inicio;
        private Panel Titulobarra;
        private PictureBox pictureBox1;
        private Label Tiempo;
        private System.Windows.Forms.Timer timer1;
    }
}
