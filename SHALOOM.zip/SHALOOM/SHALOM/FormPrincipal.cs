using FontAwesome.Sharp;
using System.Runtime.InteropServices;

namespace SHALOM
{
    public partial class FormPrincipal : Form
    {
        private IconButton currentbtn;
        private Panel leftBorderbtn;
     

        public FormPrincipal()
        {
            InitializeComponent();
            leftBorderbtn = new Panel();
            leftBorderbtn.Size = new Size(7, 60);
            Menu.Controls.Add(leftBorderbtn);
        }

        private void ActivarBoton(object senderBtn, Color color)
        {
            if (senderBtn != null)
            {
                DesactivarBoton();

                currentbtn = (IconButton)senderBtn;
                currentbtn.BackColor = Color.WhiteSmoke;
                currentbtn.ForeColor = color;
                currentbtn.TextAlign = ContentAlignment.MiddleCenter;
                currentbtn.IconColor = color;
                currentbtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentbtn.ImageAlign = ContentAlignment.MiddleRight;

                leftBorderbtn.BackColor = color;
                leftBorderbtn.Location = new Point(0, currentbtn.Location.Y);
                leftBorderbtn.Visible = true;
                leftBorderbtn.BringToFront();
            }
        }

        private void DesactivarBoton()
        {
            if (currentbtn != null)
            {
                currentbtn.BackColor = Color.WhiteSmoke;
                currentbtn.ForeColor = Color.Black;
                currentbtn.TextAlign = ContentAlignment.MiddleLeft;
                currentbtn.IconColor = Color.Black;
                currentbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentbtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }

        private void Dashboard_Click(object sender, EventArgs e)
        {
            ActivarBoton(sender, Color.Black);
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
        }

        private void Clientes_Click(object sender, EventArgs e)
        {
            ActivarBoton(sender, Color.Black);
            FormClientes clientes = new FormClientes();
            clientes.Show();
        }

        private void Pedidos_Click(object sender, EventArgs e)
        {
            ActivarBoton(sender, Color.Black);
            FormPedidos pedidos = new FormPedidos();
            pedidos.Show();
        }

        private void Pagos_Click(object sender, EventArgs e)
        {
            ActivarBoton(sender, Color.Black);
            FormPagos pagos = new FormPagos();
            pagos.Show();
        }

        private void Reportes_Click(object sender, EventArgs e)
        {
            ActivarBoton(sender, Color.Black);
            FormReportes reportes = new FormReportes();
            reportes.Show();
        }

        private void Inicio_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            DesactivarBoton();
            leftBorderbtn.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Tiempo.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }
    }
}
