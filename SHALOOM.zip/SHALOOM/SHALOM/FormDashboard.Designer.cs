﻿namespace SHALOM
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataClientes = new DataGridView();
            DataVehiculo = new DataGridView();
            DataPedido = new DataGridView();
            DataPaquete = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)DataClientes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DataVehiculo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DataPedido).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DataPaquete).BeginInit();
            SuspendLayout();
            // 
            // DataClientes
            // 
            DataClientes.Anchor = AnchorStyles.None;
            DataClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataClientes.Location = new Point(51, 90);
            DataClientes.Margin = new Padding(3, 4, 3, 4);
            DataClientes.Name = "DataClientes";
            DataClientes.RowHeadersWidth = 51;
            DataClientes.Size = new Size(546, 383);
            DataClientes.TabIndex = 0;
            // 
            // DataVehiculo
            // 
            DataVehiculo.Anchor = AnchorStyles.None;
            DataVehiculo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataVehiculo.Location = new Point(696, 90);
            DataVehiculo.Margin = new Padding(3, 4, 3, 4);
            DataVehiculo.Name = "DataVehiculo";
            DataVehiculo.RowHeadersWidth = 51;
            DataVehiculo.Size = new Size(525, 383);
            DataVehiculo.TabIndex = 1;
            // 
            // DataPedido
            // 
            DataPedido.Anchor = AnchorStyles.None;
            DataPedido.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataPedido.Location = new Point(51, 571);
            DataPedido.Margin = new Padding(3, 4, 3, 4);
            DataPedido.Name = "DataPedido";
            DataPedido.RowHeadersWidth = 51;
            DataPedido.Size = new Size(546, 397);
            DataPedido.TabIndex = 2;
            // 
            // DataPaquete
            // 
            DataPaquete.Anchor = AnchorStyles.None;
            DataPaquete.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataPaquete.Location = new Point(709, 571);
            DataPaquete.Margin = new Padding(3, 4, 3, 4);
            DataPaquete.Name = "DataPaquete";
            DataPaquete.RowHeadersWidth = 51;
            DataPaquete.Size = new Size(525, 397);
            DataPaquete.TabIndex = 3;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(279, 37);
            label1.Name = "label1";
            label1.Size = new Size(111, 27);
            label1.TabIndex = 4;
            label1.Text = "CLIENTES";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(910, 512);
            label2.Name = "label2";
            label2.Size = new Size(125, 27);
            label2.TabIndex = 5;
            label2.Text = "PAQUETES";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(281, 512);
            label3.Name = "label3";
            label3.Size = new Size(109, 27);
            label3.TabIndex = 6;
            label3.Text = "PEDIDOS";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(895, 37);
            label4.Name = "label4";
            label4.Size = new Size(140, 27);
            label4.TabIndex = 7;
            label4.Text = "VEHICULOS";
            label4.Click += label4_Click;
            // 
            // FormDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1294, 1010);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DataPaquete);
            Controls.Add(DataPedido);
            Controls.Add(DataVehiculo);
            Controls.Add(DataClientes);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormDashboard";
            Text = "FormDashboard";
            Load += FormDashboard_Load_1;
            ((System.ComponentModel.ISupportInitialize)DataClientes).EndInit();
            ((System.ComponentModel.ISupportInitialize)DataVehiculo).EndInit();
            ((System.ComponentModel.ISupportInitialize)DataPedido).EndInit();
            ((System.ComponentModel.ISupportInitialize)DataPaquete).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DataClientes;
        private DataGridView DataVehiculo;
        private DataGridView DataPedido;
        private DataGridView DataPaquete;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}